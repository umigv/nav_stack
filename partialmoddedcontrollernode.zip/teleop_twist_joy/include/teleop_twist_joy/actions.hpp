#pragma once
#include <cstdint>

// State globalState = State::TELEOP;
enum class State {
    AUTONOMOUS,
    TELEOP_ENABLED,
    TELEOP_DISABLED,
    ESTOP_ENABLED,
    ESTOP_DISABLED
};

class Action {
public:
    Action();
    
    virtual void press(uint32_t value) = 0;

    static State current_state;
};

class EStop : public Action {
public:
    // Can only switch when estop value is set to 0.
    void press(uint32_t value);
private:
    State previous_state;
};

class TeleopEnable : public Action {
public:
    // Enable button is a toggle press.
    void press(uint32_t value);
};

class AutonomousNorth : public Action {
public:
    // Only works when in ESTOP_DISABLED
    void press(uint32_t value);
};

class AutonomousSouth : public Action {
public:
    // Only works when in ESTOP_DISABLED
    void press(uint32_t value);
};