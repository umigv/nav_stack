#include <cstddef>
#include <chrono>
#include <cmath>
#include <algorithm>

class LinearRateLimiter
{
public:
    LinearRateLimiter(const double powerChangeLimit, const double currentPower) : maxChangeInPowerOverTime(powerChangeLimit)
    {
        reset(currentPower);
    }

    explicit LinearRateLimiter(const double powerChangeLimit) : LinearRateLimiter(powerChangeLimit, 0) {}

    double limit(double desiredPower);
    void reset(const double currentPower);

private:
    const double maxChangeInPowerOverTime; // units/second^2

    std::chrono::time_point<std::chrono::steady_clock, std::chrono::duration<double>> lastTimestamp;
    double lastPower; // units/second

    static std::chrono::time_point<std::chrono::steady_clock, std::chrono::duration<double>> now();

    static long millisecondsFromTimePoint(std::chrono::time_point<std::chrono::steady_clock, std::chrono::duration<double>> timePoint);
};