// TODO: fix this path, if needed
#include "../include/teleop_twist_joy/linear_rate_limiter.hpp"

// Time impl. from https://stackoverflow.com/a/36751930
using Time = std::chrono::steady_clock;
using double_sec = std::chrono::duration<double>;
using double_time_point = std::chrono::time_point<Time, double_sec>;

// change in time impl. from https://stackoverflow.com/a/36751930

double LinearRateLimiter::limit(double desiredPower)
{
    double_time_point currentTimestamp = now();

    // dt (change in time)
    double secondsSinceLastCalculate = static_cast<double>(millisecondsFromTimePoint(currentTimestamp) - millisecondsFromTimePoint(lastTimestamp)) / 1000.0;

    // original dP/dt (change in power over time)
    double absoluteChangeInPower = std::abs((desiredPower - lastPower) / (secondsSinceLastCalculate));
    // limited dP/dt
    double limitedAbsoluteChangeInPower = std::min(absoluteChangeInPower, secondsSinceLastCalculate * maxChangeInPowerOverTime);

    // dP = dP/dt * dt (change in power)
    // newPower = prevPower + dP
    double limitedPower = lastPower + (desiredPower < lastPower ? -limitedAbsoluteChangeInPower : limitedAbsoluteChangeInPower);

    lastTimestamp = currentTimestamp;
    lastPower = limitedPower;

    return limitedPower;
}

void LinearRateLimiter::reset(const double currentPower)
{
    lastTimestamp = now();
    lastPower = currentPower;
}

double_time_point LinearRateLimiter::now() {
    return Time::now();
}

long LinearRateLimiter::millisecondsFromTimePoint(double_time_point timePoint) {
    std::chrono::duration_cast<std::chrono::milliseconds>(timePoint.time_since_epoch()).count();
}