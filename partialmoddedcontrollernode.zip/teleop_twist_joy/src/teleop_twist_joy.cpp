/**
Software License Agreement (BSD)

\authors   Mike Purvis <mpurvis@clearpathrobotics.com>
\copyright Copyright (c) 2014, Clearpath Robotics, Inc., All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that
the following conditions are met:
 * Redistributions of source code must retain the above copyright notice, this list of conditions and the
   following disclaimer.
 * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the
   following disclaimer in the documentation and/or other materials provided with the distribution.
 * Neither the name of Clearpath Robotics nor the names of its contributors may be used to endorse or promote
   products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WAR-
RANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, IN-
DIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT
OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <cinttypes>
#include <functional>
#include <map>
#include <unordered_map>
#include <memory>
#include <set>
#include <string>

#include "rcutils/logging_macros.h"

#include <geometry_msgs/msg/twist.hpp>
#include <rclcpp/rclcpp.hpp>
#include <rclcpp_components/register_node_macro.hpp>
#include <sensor_msgs/msg/joy.hpp>

#include "teleop_twist_joy/teleop_twist_joy.hpp"

#include "../include/teleop_twist_joy/actions.hpp"

#define ROS_INFO_NAMED RCUTILS_LOG_INFO_NAMED
#define ROS_INFO_COND_NAMED RCUTILS_LOG_INFO_EXPRESSION_NAMED

namespace teleop_twist_joy
{

  /*
    Index	Button
    0	A (CROSS)
    1	B (CIRCLE)
    2	X (SQUARE)
    3	Y (TRIANGLE)
    4	BACK (SELECT)
    5	GUIDE (Middle/Manufacturer Button)
    6	START
    7	LEFTSTICK
    8	RIGHTSTICK
    9	LEFTSHOULDER
    10	RIGHTSHOULDER
    11	DPAD_UP
    12	DPAD_DOWN
    13	DPAD_LEFT
    14	DPAD_RIGHT
    15	MISC1 (Depends on the controller manufacturer, but is usually at a similar location on the controller as back/start)
    16	PADDLE1 (Upper left, facing the back of the controller if present)
    17	PADDLE2 (Upper right, facing the back of the controller if present)
    18	PADDLE3 (Lower left, facing the back of the controller if present)
    19	PADDLE4 (Lower right, facing the back of the controller if present)
    20	TOUCHPAD (If present. Button status only)
    Index	Axis
    0	LEFTX
    1	LEFTY
    2	RIGHTX
    3	RIGHTY
    4	TRIGGERLEFT
    5	TRIGGERRIGHT
  */

static constexpr size_t LEFT_BUMPER = 9;
static constexpr size_t RIGHT_BUMPER = 10;

static constexpr size_t DPAD_UP = 11;
static constexpr size_t DPAD_DOWN = 12;

static constexpr size_t LEFT_JOY_X_AXIS = 0;
static constexpr size_t LEFT_JOY_Y_AXIS = 1;
static constexpr size_t RIGHT_JOY_X_AXIS = 2;
static constexpr size_t RIGHT_JOY_Y_AXIS = 3;

std::unordered_map<size_t, Action*> button_map;



/**
 * Internal members of class. This is the pimpl idiom, and allows more flexibility in adding
 * parameters later without breaking ABI compatibility, for robots which link TeleopTwistJoy
 * directly into base nodes.
 */
struct TeleopTwistJoy::Impl
{
  void joyCallback(const sensor_msgs::msg::Joy::SharedPtr joy);
  void sendCmdVelMsg(const sensor_msgs::msg::Joy::SharedPtr, const std::string & which_map);

  rclcpp::Subscription<sensor_msgs::msg::Joy>::SharedPtr joy_sub;
  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr cmd_vel_pub;

  bool require_enable_button;
  int64_t enable_button;


  // Don't need to have a turbo button.
  int64_t enable_turbo_button; 

  bool inverted_reverse;

  bool sent_disable_msg;
};

/**
 * Constructs TeleopTwistJoy.
 */
TeleopTwistJoy::TeleopTwistJoy(const rclcpp::NodeOptions & options)
: rclcpp::Node("teleop_twist_joy_node", options)
{
  pimpl_ = new Impl;


  pimpl_->joy_sub = this->create_subscription<sensor_msgs::msg::Joy>(
    "joy", rclcpp::QoS(10),
    std::bind(&TeleopTwistJoy::Impl::joyCallback, this->pimpl_, std::placeholders::_1));

  // Constructing Parameters

  // pimpl_->require_enable_button = this->declare_parameter("require_enable_button", true);

  // pimpl_->enable_button = this->declare_parameter("enable_button", 5);

  // ROS_INFO_COND_NAMED(
  //   pimpl_->require_enable_button, "TeleopTwistJoy",
  //   "Teleop enable button %" PRId64 ".", pimpl_->enable_button);

  pimpl_->sent_disable_msg = false;


  button_map[LEFT_BUMPER] = new EStop();
  button_map[RIGHT_BUMPER] = new TeleopEnable();

  



  // auto param_callback =
  //   [this](std::vector<rclcpp::Parameter> parameters)
  //   {
  //     rcl_interfaces::msg::SetParametersResult result;
  //     result.successful = true;

  //     // Loop to assign changed parameters to the member variables
  //     for (const auto & parameter : parameters) {
  //       if (parameter.get_name() == "enable_button") {
  //         this->pimpl_->enable_button = parameter.get_value<rclcpp::PARAMETER_INTEGER>();
  //       }
  //     }
  //     return result;
  //   };

  // callback_handle = this->add_on_set_parameters_callback(param_callback);
}

TeleopTwistJoy::~TeleopTwistJoy()
{
  delete pimpl_;

  // Loop through all button mappings and delete action pointers.
  for (auto iter : button_map) {
    delete iter.second;
  }
}

void TeleopTwistJoy::Impl::sendCmdVelMsg(
  const sensor_msgs::msg::Joy::SharedPtr joy_msg,
  const std::string & which_map)
{
  // Initializes with zeros by default.
  // auto cmd_vel_msg = std::make_unique<geometry_msgs::msg::Twist>();

  // double lin_x = getVal(joy_msg, axis_linear_map, scale_linear_map[which_map], "x");
  // double ang_z = getVal(joy_msg, axis_angular_map, scale_angular_map[which_map], "yaw");

  // cmd_vel_msg->linear.x = lin_x;
  // cmd_vel_msg->linear.y = getVal(joy_msg, axis_linear_map, scale_linear_map[which_map], "y");
  // cmd_vel_msg->linear.z = getVal(joy_msg, axis_linear_map, scale_linear_map[which_map], "z");
  // cmd_vel_msg->angular.z = (lin_x < 0.0 && inverted_reverse) ? -ang_z : ang_z;
  // cmd_vel_msg->angular.y = getVal(joy_msg, axis_angular_map, scale_angular_map[which_map], "pitch");
  // cmd_vel_msg->angular.x = getVal(joy_msg, axis_angular_map, scale_angular_map[which_map], "roll");

  // cmd_vel_pub->publish(std::move(cmd_vel_msg));
  // sent_disable_msg = false;
}

// https://github.com/ros2/teleop_twist_joy/blob/a9e2f3432f3b79fbdd9b1ac5f927618ab9eca92f/src/teleop_twist_joy.cpp
void TeleopTwistJoy::Impl::joyCallback(const sensor_msgs::msg::Joy::SharedPtr joy_msg)
{
  /*
    Want to add publisher/service that runs the navigation stack with both north and south configs.

    Thinking of using the up and down buttons.
  */

  /*
    Want one of the buttons to publish to the estop topic.
  */

    for (size_t i = 0; i < joy_msg->buttons.size(); i++) {
      auto binding = button_map.find(i);

      if (binding != button_map.end()) {
        binding->second->press(joy_msg->buttons[i]);
      }
      
    }








  // if (enable_turbo_button >= 0 &&
  //   static_cast<int>(joy_msg->buttons.size()) > enable_turbo_button &&
  //   joy_msg->buttons[enable_turbo_button])
  // {
  //   sendCmdVelMsg(joy_msg, "turbo");
  // } else if (!require_enable_button ||  // NOLINT
  //   (static_cast<int>(joy_msg->buttons.size()) > enable_button &&
  //   joy_msg->buttons[enable_button]))
  // {
  //   sendCmdVelMsg(joy_msg, "normal");
  // } else {
  //   // When enable button is released, immediately send a single no-motion command
  //   // in order to stop the robot.
  //   if (!sent_disable_msg) {
  //     // Initializes with zeros by default.
  //     auto cmd_vel_msg = std::make_unique<geometry_msgs::msg::Twist>();
  //     cmd_vel_pub->publish(std::move(cmd_vel_msg));
  //     sent_disable_msg = true;
  //   }
  // }
}

}  // namespace teleop_twist_joy

RCLCPP_COMPONENTS_REGISTER_NODE(teleop_twist_joy::TeleopTwistJoy)