#include "../include/teleop_twist_joy/actions.hpp"

State Action::current_state;

Action::Action() {
    current_state = State::TELEOP_DISABLED;
}

void EStop::press(uint32_t value) {
    switch (value) {
        case 0:
            current_state = State::ESTOP_DISABLED;
            break;
        case 1:
            current_state = State::ESTOP_ENABLED;
            break;
    }
}

void TeleopEnable::press(uint32_t value) {
    switch (value) {
        case 0:
            current_state = State::TELEOP_DISABLED;
            break;
        case 1:
            current_state = State::TELEOP_ENABLED;
            break;
    }
}

void AutonomousNorth::press(uint32_t value) {
    /*
        Need to think about how to implement this.
        run a launch file?
        Call a service?
    */

   /*
        AutonomousNorth is a service client to the navigation stack.

        When the nav stack is turned on it will loop until the run service is called.

        The service will take a north or south bool.
   */

    return;
}

void AutonomousSouth::press(uint32_t value) {
    /*
        Need to think about how to implement this.
        run a launch file?
        Call a service?
    */
    return;
}